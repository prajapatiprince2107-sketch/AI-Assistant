SHALU AI 13.0 — LOCAL NEURAL VOICE
====================================

What is new:
- Local Piper neural TTS instead of browser SpeechSynthesis.
- No ElevenLabs account or API key.
- 3D SHALU.vrm included.
- Emotion detection + VRM expressions.
- Sentence-by-sentence speaking and natural pauses.
- Gentle idle motion + blinking.
- Voice generation happens on your PC.

FIRST TIME:
1. Make sure Python is installed and "python" works in CMD.
2. Double-click SETUP_SHALU_13_NEURAL.bat.
3. Wait for Piper + the voice model to finish installing.
4. A browser window will open automatically.

NEXT TIMES:
- Double-click START_SHALU_13_NEURAL.bat.

IMPORTANT:
- First setup needs internet to install/download the voice.
- After setup, voice synthesis is local.
- The included model is not a clone of the reference video speaker.
- If your Python installation is very new and Piper installation fails,
  use a supported stable Python version and rerun setup.


SHALU AI 14.0
-------------
Enhanced 3D conversational animation: live audio-driven mouth shapes, stronger emotion hold, natural head/neck/chest movement, subtle arm movement, breathing and improved blinking. Lip-sync is real-time approximate, not phoneme-perfect.
